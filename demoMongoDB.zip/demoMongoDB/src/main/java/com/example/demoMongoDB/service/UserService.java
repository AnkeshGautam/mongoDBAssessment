package com.example.demoMongoDB.service;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoMongoDB.model.UserModel;
import com.example.demoMongoDB.repository.UserRepo;

@Service
public class UserService {
	@Autowired
	private UserRepo userRepo;
	
	public String createEmployee(UserModel u) {
		userRepo.save(u);
		return ("New user created with ID: "+ u.getEmp_id());
	}
	
	public void updateEmployee(UserModel u) {
		userRepo.save(u);
	}
	
	public List<UserModel> listEmployee(){
		return userRepo.findAll();
	}
	
	public String deleteEmployeeById(String emp_id) {
        userRepo.deleteById(emp_id);
        return "Successful";
    }
	
	public void deleteAll() {
		userRepo.deleteAll();
	}
}
