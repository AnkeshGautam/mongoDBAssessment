package com.example.demoMongoDB.model;

import java.math.BigInteger;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employee")
public class UserModel {
	@Id
	private String emp_id;
	private String employeeName;
	private String employeeDepartment;
	private String reportingManager;
	private int employeeAge;
	private BigInteger employeeSalary;
	
	public UserModel(String employeeName, String employeeDepartment, String reportingManager, int employeeAge,
			BigInteger employeeSalary) {
		super();
		this.employeeName = employeeName;
		this.employeeDepartment = employeeDepartment;
		this.reportingManager = reportingManager;
		this.employeeAge = employeeAge;
		this.employeeSalary = employeeSalary;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeDepartment() {
		return employeeDepartment;
	}
	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}
	public String getReportingManager() {
		return reportingManager;
	}
	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	public BigInteger getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(BigInteger employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	
	
}
