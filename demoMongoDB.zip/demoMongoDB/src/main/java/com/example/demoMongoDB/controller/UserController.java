package com.example.demoMongoDB.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoMongoDB.model.UserModel;
import com.example.demoMongoDB.service.UserService;

@RestController
@RequestMapping(value = "/employee", method = RequestMethod.GET)
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/add")
	public String creatUser(@RequestBody UserModel u) {
		return userService.createEmployee(u);
	}

	@PutMapping(value = "/update")
	public String update(@RequestBody UserModel u) {
		userService.updateEmployee(u);
		return "Employee record for employee-id= " + " updated.";
	}

	@GetMapping("/list")
	public List<?> listUsers() {
		return userService.listEmployee();
	}

	@DeleteMapping("/delete/{emp_id}")
	public String delete(@PathVariable(value = "emp_id") String emp_id) {
		return userService.deleteEmployeeById(emp_id);
	}
	
	@DeleteMapping(value = "/deleteAll")
	public void deleteAllEmp() {
		userService.deleteAll();
	}
}
